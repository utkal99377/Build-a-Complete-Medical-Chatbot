from flask import Flask, render_template, jsonify, request
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_community.llms import Ollama
from langchain_community.document_loaders import PyPDFLoader
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate
import os

app = Flask(__name__)

# Lazy load global variables
retriever = None
rag_chain = None


def initialize_chain():
    global retriever, rag_chain

    if retriever and rag_chain:
        return  # Already initialized

    pdf_path = "data/Medical_book.pdf"
    loader = PyPDFLoader(pdf_path)
    pages = loader.load()

    embeddings = HuggingFaceEmbeddings(model_name="sentence-transformers/all-mpnet-base-v2")
    db = FAISS.from_documents(pages, embeddings)
    retriever = db.as_retriever(search_type="similarity", search_kwargs={"k": 3})

    llm = Ollama(model="llama3")
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful medical assistant."),
        ("human", "{input}"),
    ])

    question_answer_chain = create_stuff_documents_chain(llm, prompt)
    rag_chain = create_retrieval_chain(retriever, question_answer_chain)


@app.route("/")
def home():
    return render_template("chat.html")


@app.route("/chat", methods=["POST"])
def chat():
    try:
        initialize_chain()
        data = request.get_json()
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"response": "⚠️ Please enter a message."})

        response = rag_chain.invoke({"input": user_message})
        return jsonify({"response": response["answer"]})

    except Exception as e:
        print("❌ Error:", str(e))
        return jsonify({"response": f"❌ Server error: {str(e)}"})


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=8080, debug=True)
